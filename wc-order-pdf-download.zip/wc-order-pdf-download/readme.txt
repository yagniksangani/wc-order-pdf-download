=== WC Order PDF Download ===
Contributors: yagniksangani
Tags: woocommerce, pdf, invoices, order, print
Requires at least: 3.5
Tested up to: 5.4
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Download PDF for WooCommerce orders.

== Description ==
This WooCommerce extension generates a PDF invoice for your woocommerce orders. Admin can download order pdf from the order admin page and customers can download order pdf from the my account page.

= Features =
* Download the PDF invoice from the order admin page.
* Download invoices from the My Account page

== Installation ==
1. Upload plugin to the "/wp-content/plugins/" directory.
2. Activate the plugin through the "Plugins" menu in WordPress.

= 1.0.0 =
* Initial release.
